//
//  ABSplashAd.h
//  AdBundSDK
//
//  Created by amy on 16/6/28.
//  Copyright © 2016年 zhengs. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ABSplashAdDelegate <NSObject>
    @optional
        -(void)ABSplashLoaded;
        -(void)ABSplashClicked;
        -(void)ABSplashFailed;
        -(void)ABSplashSkiped;
@end

@interface ABSplashAd : UIView
@property (nonatomic, weak, nullable) id<ABSplashAdDelegate> delegate;
-(nonnull id)initWithSlot:(nonnull NSString *)slotid adSize:(CGRect)frame rootViewController:(nullable UIViewController *)viewController;
@end
