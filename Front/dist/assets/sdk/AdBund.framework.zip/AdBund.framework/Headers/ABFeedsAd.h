//
//  ABFeedsAd.h
//  AdBundSDK
//
//  Created by amy on 16/6/28.
//  Copyright © 2016年 zhengs. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ABFeedsAdDelegate <NSObject>
    @optional
        -(void)loaded;
        -(void)clicked;
        -(void)failed;
@end

@interface ABFeedsAd : UIView
@property (nonatomic, weak, nullable) id<ABFeedsAdDelegate> delegate;
-(nonnull id)initWithSlot:(nonnull NSString *)slotid adSize:(CGRect)frame rootViewController:(nullable UIViewController *)viewController;
@end
