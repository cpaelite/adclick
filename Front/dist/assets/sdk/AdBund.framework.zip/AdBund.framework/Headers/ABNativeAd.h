//
//  ABNativeAd.h
//  AdBundSDK
//
//  Created by amy on 16/6/28.
//  Copyright © 2016年 zhengs. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol ABNativeAdDelegate <NSObject>
    @optional
        -(void)loaded;
        -(void)clicked;
        -(void)failed;
@end

@interface ABNativeAd : UIView
@property (nonatomic, weak, nullable) id<ABNativeAdDelegate> delegate;
@end