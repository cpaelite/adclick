//
//  ABBanner.h
//  AdBundSDK
//
//  Created by amy on 16/6/28.
//  Copyright © 2016年 zhengs. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ABBannerAdDelegate <NSObject>
    @optional
        -(void)ABBannerLoaded;
        -(void)ABBannerClicked;
        -(void)ABBannerFailed;
        -(void)ABBannerClosed;
@end

@interface ABBannerAd : UIView
@property (nonatomic, weak, nullable) id<ABBannerAdDelegate> delegate;
-(nonnull id)initWithSlot:(nonnull NSString *)slotid adSize:(CGRect)frame rootViewController:(nullable UIViewController *)viewController;
@end